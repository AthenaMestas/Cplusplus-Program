/*
Athena Mestas
8/17/2024
CS-210 Project Three: Final
*/

#include <iostream>
#include <fstream> // Allows for file input/output operations

#include "ItemTracker.h" // Includes item tracker class (ItemTracker.h)

int main() {
	ItemTracker tracker; // Creates an instance of the item tracker class

	// Loads data from specified file - change file name to load different data
	tracker.LoadData("CS210_Project_Three_Input_File.txt"); // The load data class object handles any file-related issues

	tracker.DisplayMenu(); // Displays functional menu
	tracker.BackupData("frequency.dat"); // Backs up data into the frequency.dat file after the menu loop exits

	return 0;
}