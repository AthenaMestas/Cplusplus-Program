#include <iomanip> // For appearance manipulation with output
#include <vector> // For storing and sorting items (in the print frequencies class object)
#include <algorithm> // For std::sort
#include <iostream>

#include "ItemTracker.h" // Includes item tracker class (ItemTracker.h)

// Defines load data class object: Loads data from file and populates the item frequency map
void ItemTracker::LoadData(const std::string& filename) {
	std::ifstream inputFile(filename);
	std::string item;

	if (inputFile.is_open()) {
		while (inputFile >> item) { // Loops through each item from the file 
			itemFrequency[item]++; // Increments the item frequency in the item frequency map
		}
		inputFile.close(); // Closes the file 
	}
	else {
		std::cerr << "Error opening file: " << filename << std::endl; /*Handles any errors encountered when attempting to open file:
		                                                                Similar to std::cout, std::cerr is more appropriate for printing
																		error messages */
	}
}

// Defines get item frequency class object: Returns the frequency of a specified item or returns 0 if the item is not found
int ItemTracker::GetItemFrequency(const std::string& item) const {
	auto it = itemFrequency.find(item); // auto decuces the variable type of "it" as an iterator to "std::pair<const std::string, int>"
	if (it != itemFrequency.end()) {
		return it->second; // Returns the item frequency: "second" referes to the second part of the key-value pair (value)
	}
	else {
		return 0; // Returns 0 if the item is not found
	}
}

// Defines print frequencies class object: Prints all item frequencies
void ItemTracker::PrintFrequencies() const {
	const int width = 15; // Defines width for allignment

	std::vector<std::pair<std::string, int>> items(itemFrequency.begin(), itemFrequency.end()); // Converts the map to a vector of pairs for sorting

	// Sorts the vector by frequencies in descending order
	std::sort(items.begin(), items.end(), [](const auto& a, const auto& b) { /* Uses a lambda function: [capture list] (parameters) -> return type
		                                                                        The [capture list] is empty because it does not need to capture any
																				variables. The parameters are a and b. The "->" is left out and the
																				lambda function returns a bool.*/
		return a.second > b.second; // Returns the sorting by frequencies (in descending order): if the return is true, a will come before b and visa-versa
		});

	for (const auto& pair : items) {
		// "pair.first" referes to the item, "pair.second" referes to the frequency
		std::cout << std::left << std::setw(width) << pair.first << pair.second << std::endl; 
	}
}

// Defines print histogram class object: Prints all item frequencies in a histogram using "*"
void ItemTracker::PrintHistogram() const {
	int i;
	const int width = 15; // Adjusts width for histogram (between the item name and the "*"s)

	for (const auto& pair : itemFrequency) { // Creates a range-based for-loop where "const auto& pair" makes sure "pair" is a map element
		std::cout << std::left << std::setw(width) << pair.first; // Manipulates histogram structure and includes the item name

		std::string color; // Declares color
		// Decides the color of "*"s based on frequencies (uses ANSI escape codes)
		if (pair.second >= 10) {
			color = "\033[1;35m"; // Pink for high-frequency (>=10)
		}
		else if (pair.second >= 5) {
			color = "\033[1;34m"; // Purple for medium frequency (5-9)
		}
		else {
			color = "\033[1;36m"; // Blue for low frequency (<5)
		}

		std::cout << color;
		// Includes the "*"s in color
		for (i = 0; i < pair.second; ++i) {
			std::cout << "*";
		}
		std::cout << "\033[0m" << std::endl; // Resets color after printing "*"s
	}
}

// Defines backup data class object: Backs up item frequencies to a specified file
void ItemTracker::BackupData(const std::string& filename) const {
	std::ofstream outputFile(filename);

	if (outputFile.is_open()) {
		for (const auto& pair : itemFrequency) { // Writes each item and the item's frequency to the file
			outputFile << pair.first << " " << pair.second << std::endl; 
		}
		outputFile.close(); // Closes the file
	}
	else {
		std::cerr << "Error opening file: " << filename << std::endl; // Handles any errors encountered when attempting to open file
	}
}

// Defines display menu class object: Displays menu screen and handles user interaction/input
void ItemTracker::DisplayMenu() {
	int choice;
	std::string item;

	// The functional menue is held within a do-while loop
	do { 
		// Prints menu options
		std::cout << "\n\n ----------------- ~ Menu ~ -----------------\n"; 
		std::cout << "| 1 ~ Search for an item                     |\n";
		std::cout << "| 2 ~ Display all items and their frequencies|\n";
		std::cout << "| 3 ~ Display histogram                      |\n";
		std::cout << "| 4 ~ Exit                                   |\n";
		std::cout << " --------------------------------------------\n";

		// Input validation:
		while (true) {
			std::cout << "\n\n~ Enter your choice (1-4): ";
			std::cin >> choice;

			if (std::cin.fail() || choice < 1 || choice > 4) { // If input retrieval fails or user input is less than 1 or greater than 4
				std::cin.clear(); // Clears error flag
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignores invalid input
				std::cout << "Invalid input. Please enter a number between 1 and 4.\n";
			}
			else {
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clears buffer
				break; // Exits loop if input is valid
			}
		}
		
		// Switch statement to handle user's choice
		switch (choice) {
		case 1:
			std::cout << "Enter item name: ";
			std::cin >> item;
			std::cout << item << " frequency: " << GetItemFrequency(item) << std::endl; // Uses the get item frequency class object
			break;
		case 2:
			PrintFrequencies(); // Calls the print frequencies class object
			break;
		case 3:
			PrintHistogram(); // Calls the print histogram class object
			break;
		case 4:
			std::cout << "Exiting program.\n";
			break;
		default:
			std::cout << "Invalid choice. Please try again.\n"; // Input validation
			break;
		}
	} while (choice != 4); // Continues to loop until the user enters "4"
}
