#pragma once

#ifndef ITEMTRACKER_H 
#define ITEMTRACKER_H

#include <iostream>
#include <map> // Allows for maps
#include <string>
#include <fstream> // Allows for file input/output operations

class ItemTracker {
public:
	void LoadData(const std::string& filename); // Loads data from specified file
	int GetItemFrequency(const std::string& item) const; // Gets the item frequency

	void PrintFrequencies() const; // Prints all items and each of their frequencies
	void PrintHistogram() const; // Prints a histogram for all items and each of their frequencies

	void BackupData(const std::string& filename) const; // Backs up data to specified file

	void DisplayMenu(); // Displays menu and handles user interaction

private:
	std::map<std::string, int> itemFrequency; /* Map to hold item frequencies : std::string is the key and int is the value in the
	                                             key-value pairs */
};

#endif 